#!/system/bin/sh

su -c iptables -F
iptables -F
su -c iptables --flush
iptables --flush
iptables -F
iptables -X
ip6tables --flush
ip6tables -F
su -c iptables -F
su -c iptables -X
su -c ip6tables --flush
su -c ip6tables -F

iptables -I INPUT -p tcp --dport 17500 -j REJECT
iptables -I OUTPUT -p tcp --dport 17500 -j REJECT
iptables -I INPUT -p udp --dport 17000 -j REJECT
iptables -I OUTPUT -p udp --dport 17000 -j REJECT
iptables -I INPUT -p tcp --dport 18500 -j REJECT
iptables -I OUTPUT -p tcp --dport 18500 -j REJECT
