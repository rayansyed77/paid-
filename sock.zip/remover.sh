cp /data/data/com.ayan.pk/files/libhook.so /data/local/tmp/libhook.so
chmod 777 /data/local/tmp/libhook.so
sleep 2
rm -rf /data/data/com.ayan.pk/files/remover.sh
rm -rf /data/data/com.ayan.pk/files/libhook.so